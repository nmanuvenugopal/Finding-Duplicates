'''Given an integer array nums,
return true if any value appears at least twice in the array,
and return false if every element is distinct.
'''

# Easiest way is to convert the list to Set.
# Find the length of the Set and List.
# If both are equal then return False (no duplicates).
# If both are different then return True (Duplicates are there).
# Since Set does not allows duplicates so it removes them while conversion.
# But list allows duplicates.

numbers = input("Enter the list of integers separated by commas: ").split(',')

num_list = list(map(int, numbers))

def containsDuplictaes(number_list):
    if len(set(number_list)) == len(number_list):
        return False
    else:
        return True

if containsDuplictaes(num_list):
    print(f"{num_list} contains duplicates")
else:
    print(f"{num_list} does not contains duplicates")